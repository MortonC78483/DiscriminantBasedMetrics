# Images used by the template
These images are used by the template. Please do not remove.
